## Analyse Hack-a-thon


### Installing using pip
pip install git+https://github.com/ShivaanSook/recsort.git

### Upgrading version using pip
pip install --upgrade git+https://github.com/ShivaanSook/recsort.git

